/******************************************************************************
 * Class: DealerHand
 * Author: Shuaike Zhou
 * Email: szhou97@bu.edu
 *****************************************************************************/
package structure.participant;
/**
 * A dealer hand class to instantiate hand
 */
public class DealerHand extends Hand {
    public DealerHand() {

    }
}
